from django.db import models
from django.contrib.auth.models import User
from django.utils.text import slugify
from django.urls import reverse
from pytils.translit import slugify as translit_slugify
from taggit.managers import TaggableManager

class Post(models.Model):
    author = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="posts",
        verbose_name="Автор",
        null=True,
        blank=True,
    )
    title = models.CharField("Заголовок", max_length=100)
    slug = models.SlugField(
        max_length=200,
        unique=True,
        blank=True,
        unique_for_date='created_at',
        null=True,
    )
    body = models.TextField("Текст")
    created_at = models.DateTimeField("Создано", auto_now_add=True)
    updated_at = models.DateTimeField("Обновлено", auto_now=True)
    is_published = models.BooleanField("Опубликовано", default=False)

    class Meta:
        ordering = ['-created_at']
        verbose_name = "Пост"
        verbose_name_plural = "Посты"

    def __str__(self):
        return self.title

    tags = TaggableManager()

    def save(self, *args, **kwargs):

        # Обновляем slug, если он пустой ИЛИ содержит не-латинские символы
        if not self.slug or not self.slug.isascii():
            base_slug = translit_slugify(self.title)
            slug = base_slug
            counter = 1

            # Ищем свободный слаг
            while Post.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1

            self.slug = slug  # ✅ ИСПРАВЛЕНО: сохраняем уникальный slug, а не base_slug
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('blog:post_detail', kwargs={
            'year': self.created_at.year,
            'month': self.created_at.month,
            'day': self.created_at.day,
            'slug': self.slug
        })

    def get_edit_url(self):
        return reverse(
            'blog:post_edit',
            kwargs={
                'year': self.created_at.year,
                'month': self.created_at.month,
                'day': self.created_at.day,
                'slug': self.slug,
            }
        )

    def get_delete_url(self):
        return reverse(
            'blog:post_delete',
            kwargs={
                'year': self.created_at.year,
                'month': self.created_at.month,
                'day': self.created_at.day,
                'slug': self.slug,
            }
        )

class Comment(models.Model):
    post = models.ForeignKey(
        Post,
        on_delete=models.CASCADE,
        related_name="comments",
        verbose_name="Пост",
    )
    author = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="comments",
        verbose_name="Автор",
        null=True,
        blank=True,
    )
    text = models.TextField("Текст комментария")
    created_at = models.DateTimeField("Создано", auto_now_add=True)

    def __str__(self):
        return f"Комментарий от {self.author}"