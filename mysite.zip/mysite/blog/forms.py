from django import forms
from django.core.exceptions import ValidationError
from .models import Post, Comment



class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ["title", "body", "is_published"]


    def clean(self):
        cleaned_data = super().clean()
        title = cleaned_data.get('title')
        body = cleaned_data.get('body')

        # Простое правило для демонстрации
        if title and body and title == body:
            raise ValidationError("Заголовок и текст поста не должны совпадать!")

        return cleaned_data

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ["author", "text"]