from . import views as blog_views
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

app_name = 'blog'

urlpatterns=[
    path("admin/",admin.site.urls),
    path("",blog_views.home,name="home"),
    path("blog/",blog_views.post_list,name="post_list"),
    path('tag/<slug:tag_slug>/', blog_views.post_list, name='post_list_by_tag'),
    path("about/",blog_views.about,name="about"),
    path("blog/create/",blog_views.post_create,name="post_create"),
    path('accounts/password_reset/', blog_views.DevPasswordResetView.as_view(), name='password_reset'),  # ← новую
    path("accounts/", include("django.contrib.auth.urls")),
    path("accounts/", include("accounts.urls")),
    path('<int:year>/<int:month>/<int:day>/<slug:slug>/',
        blog_views.post_detail,
        name='post_detail'),
    path('<int:year>/<int:month>/<int:day>/<slug:slug>/edit/',
        blog_views.post_edit,
        name='post_edit'),
    path('<int:year>/<int:month>/<int:day>/<slug:slug>/delete/',
        blog_views.post_delete,
        name='post_delete')
]

if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)