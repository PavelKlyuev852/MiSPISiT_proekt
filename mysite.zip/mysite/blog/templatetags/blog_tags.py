from django import template
from django.db.models import Count
from..models import Post
from taggit.models import Tag

register=template.Library()

@register.simple_tag
def total_posts():
    """Возвращаетобщееколичествоопубликованныхпостов"""
    return Post.objects.filter(is_published=True).count()

@register.inclusion_tag('blog/latest_posts.html')
def show_latest_posts(count=5):
    """Отображает последние N постов"""
    latest_posts=Post.objects.filter(
        is_published=True
    ).order_by('-created_at')[:count]
    return{'latest_posts': latest_posts}

@register.inclusion_tag('blog/tag_cloud.html')
def show_tag_cloud():
    """Отображаетоблакотеговсподсчётомпостов"""
    tags=Tag.objects.annotate(
        num_posts=Count('taggit_taggeditem_items')
    ).filter(num_posts__gt=0).order_by('-num_posts')
    return {'tags': tags}