from .models import Post,Comment
from django.shortcuts import render, get_object_or_404, redirect
from .forms import PostForm, CommentForm
from django.db.models import Q
from django.core.paginator import Paginator
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from taggit.models import Tag


def post_list(request, tag_slug=None):
    query=request.GET.get("q", "").strip()
    posts_qs=Post.objects.filter(is_published=True)
    tag = None
    if tag_slug:
        tag = get_object_or_404(Tag, slug=tag_slug)
        posts_qs = posts_qs.filter(tags=tag)
    if query:
        posts_qs=posts_qs.filter(
            Q(title__icontains=query)|Q(body__icontains=query)
        )
    #пагинация
    paginator=Paginator(posts_qs,3) #3 постов на страницу
    page_number=request.GET.get("page")
    page_obj=paginator.get_page(page_number)
    context={
        "posts":page_obj, #теперь posts=текущая страница
        "page_obj":page_obj,
        "query":query,
        "tag": tag,
    }
    return render(request, "blog/post_list.html",context)

def home(request):
    context = {}
    return render(request, "blog/home.html", context)

def about(request):
    context = {}
    return render(request, "blog/about.html", context)

def post_detail(request, year, month, day, slug):
    post = get_object_or_404(
        Post,
        is_published=True,
        slug=slug,
        created_at__year=year,
        created_at__month=month,
        created_at__day=day,
    )
    comments = post.comments.all()  # ← Обязательно!
    form = CommentForm()
    if request.method == "POST" and request.user.is_authenticated:
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.author = request.user
            comment.save()
            return redirect(post.get_absolute_url())

    return render(request, "blog/post_detail.html", {
        "post": post,
        "comments": comments,  # ← Передаём в шаблон
        "form": form
    })



@login_required
def post_create(request):
    if request.method == "POST":
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            return redirect(
                "blog:post_detail",
                year=post.created_at.year,
                month=post.created_at.month,
                day=post.created_at.day,
                slug=post.slug
            )
    else:
        form = PostForm()
    return render(request, "blog/post_form.html", {"form": form})

@login_required
def post_edit(request, year, month, day, slug):
    post = get_object_or_404(
        Post,
        is_published=True,
        slug=slug,
        created_at__year=year,
        created_at__month=month,
        created_at__day=day
    )

    if not request.user.is_superuser:
        # Если редактирование запрещено, показываем сообщение и прерываем работу
        return render(request, 'blog/post_form_edit.html', {
            'block_message': 'Редактирование постов временно отключено!',
            'post': post,
            'form': None
        })

    if request.method == "POST":
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            post = form.save()
        return redirect(post.get_absolute_url())
    else:
        form = PostForm(instance=post)
    context = {"form": form, "post": post}
    return render(request, "blog/post_form_edit.html", context)

def post_delete(request, year, month, day, slug):
    post = get_object_or_404(
        Post,
        is_published=True,
        slug=slug,
        created_at__year=year,
        created_at__month=month,
        created_at__day=day
    )

    if not request.user.is_superuser:
        # Если удаление запрещено, показываем сообщение и прерываем работу
        return render(request, 'blog/post_confirm_delete.html', {
            'block_message': 'Удаление постов временно отключено!',
            'post': post,
            'form': None
        })

    if request.method == "POST":
        post.delete()
        return redirect("blog:post_list")
    context = {"post": post}
    return render(request, "blog/post_confirm_delete.html", context)


from django.contrib.auth.views import PasswordResetView
from django.urls import reverse
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.contrib.auth import get_user_model
from django.conf import settings

User = get_user_model()

class DevPasswordResetView(PasswordResetView):
    """Выводит в консоль чистую ссылку для сброса (только DEBUG)"""
    def form_valid(self, form):
        if settings.DEBUG:
            email = form.cleaned_data['email']
            user = User.objects.filter(email=email).first()
            if user:
                # Генерируем UID и токен так же, как это делает Django
                uid = urlsafe_base64_encode(force_bytes(user.pk))
                token = default_token_generator.make_token(user)

                # Собираем абсолютную ссылку
                clean_url = self.request.build_absolute_uri(
                    reverse('password_reset_confirm', kwargs={'uidb64': uid, 'token': token})
                )

                # Печатаем аккуратно, без разрывов строк
                print("\n" + "="*60)
                print("🔑 СКОПИРУЙ ЭТУ ССЫЛКУ (одной строкой!):")
                print(clean_url)
                print("="*60 + "\n")

        # Продолжаем стандартную отправку письма на email
        return super().form_valid(form)