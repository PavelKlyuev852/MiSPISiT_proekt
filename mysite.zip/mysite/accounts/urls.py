from django.urls import path
from. import views

#app_name = 'accounts'

urlpatterns=[
    path("signup/",views.signup,name="signup"),
    path("profile/",views.profile_view,name="profile"),
    path("profile/edit/",views.profile_edit,name="profile_edit"),
    path("users/<str:username>/",views.profile_view,name="user_profile"),
]